import mysql.connector
import random

def create_connection():
    
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="#Workingonit",
        database="user"
    )
    return mydb

def Register(mycursor):
    print("_"*5 + "Sign_up" + "_"*5)
    print()
    Firstname = input("Enter Firstname: ")
    Lastname = input("Enter Lastname: ")
    Login_id = input("Enter Login ID: ")
    Password = input("Enter password: ")
    Cpassword = input("Please confirm your password: ")
    if Password == Cpassword:
        sql = "INSERT INTO details (Firstname, Lastname, Login_id, password) VALUES (%s, %s, %s, %s)"
        val = (Firstname, Lastname, Login_id, Password)
        mycursor.execute(sql, val)
        print(mycursor.rowcount, "record inserted.")
    else:
        print("Please check your password again....!")

def QUIZ(mycursor):
   
        quiz_data = read_quiz_data("quiz.txt")
        num_questions_to_select = 10  # Adjust the number of questions as needed
        selected_questions = select_random_questions(quiz_data, num_questions_to_select)
        user_score = take_quiz(selected_questions)
        print(f"Your score: {user_score}/{num_questions_to_select}")

        

def login(mycursor):
    Login_id = input("Enter Login ID: ")
    password = input("Enter password: ")

    query = "SELECT * FROM details WHERE Login_id = %s AND password = %s"
    mycursor.execute(query, (Login_id, password))
    result = mycursor.fetchone()
    

    if result is not None and result[2] == Login_id and result[3] == password:
        
        print("Login successful!!!")

        print()

        print("\n1.Attempt Quiz\n2.Logout")
        ch=input("press 1/2")
        if(ch=='1'):
            QUIZ(mycursor)

        elif(ch==2):
            exit
    else:
        print("Invalid credentials. Please try again.")
        return None
                

def read_quiz_data(filename):
    with open(filename, "r") as file:
        lines = file.readlines()

    quiz_data = []
    for line in lines:
        parts = line.strip().split("|")
        question = parts[0]
        options = parts[1:-1]
        correct_answer = parts[-1]
        quiz_data.append({"question": question, "options": options, "correct_answer": correct_answer})

    return quiz_data

def display_quiz(quiz):
    print("\nQuiz Questions:")
    for question_number, question in enumerate(quiz, start=1):
        print(f"\nQuestion: {question['question']}")
        print("Options:")
        for option_number, option in enumerate(question['options'], start=1):
            print(f"{option_number}. {option}")
        print("")

def select_random_questions(quiz_data, num_questions):
    random.shuffle(quiz_data)
    selected_questions = quiz_data[:num_questions]
    return selected_questions

def take_quiz(quiz):
    score = 0
    for question in quiz:
        display_quiz([question])
        user_answer = input("Enter your answer (A, B, C, D): ").strip().upper()
        if user_answer == question["correct_answer"]:
            print("Correct!")
            score += 1
        else:
            print(f"Incorrect! Correct answer is {question['correct_answer']}")
    return score

def main():
    connection = create_connection()
    mycursor = connection.cursor(buffered=True)
    print("Welcome")

    while True:
        print("\n1.Register\n2.Login for Attempting Quiz")
        choice = input("Enter your choice (1/2):")

        if choice == '1':
            Register(mycursor)

        elif choice == '2':
            firstname = login(mycursor)
            if firstname:
                print(f"Welcome, {firstname}!")
        
        else:
            print("Invalid choice. Please try again.")
        connection.commit()
    connection.close()

if __name__ == "__main__":
    main()
